import type { Metadata } from "next";
import Link from "next/link";
import { JsonLd } from "@/components/seo/json-ld";
import { AuthorityVisualSection, PlainEnglishSummary } from "@/components/authority";
import { buildAuthorityPageStructuredData } from "@/lib/seo/structured-data";
import { authorityEditorialDates } from "@/lib/seo/editorial-dates";

const title =
  "Transcutaneous Vagus Nerve Stimulation | tVNS Guide | Neuvago";
const description =
  "Learn how transcutaneous vagus nerve stimulation works as a method family, which protocol details matter, and how tVNS evidence should be interpreted.";
const path = "/learn/transcutaneous-vagus-nerve-stimulation";

export const metadata: Metadata = {
  title,
  description,
  alternates: {
    canonical: path,
    languages: {
      "en-US": path,
      "nb-NO": "/no/kunnskap/transkutan-vagusnervestimulering",
      "x-default": path,
    },
  },
  openGraph: {
    title,
    description,
    url: path,
    siteName: "Neuvago",
    locale: "en_US",
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
  },
};

const quickAnswers = [
  {
    title: "Transcutaneous means through the skin",
    description:
      "Transcutaneous vagus nerve stimulation uses external contact rather than implanted hardware. In VNS conversations, it usually refers to non-invasive stimulation applied at the ear or neck area.",
  },
  {
    title: "tVNS is a method family, not one single protocol",
    description:
      "The term can include auricular approaches, cervical approaches, different electrodes, different settings, and different research goals. The details matter.",
  },
  {
    title: "taVNS is the ear-based branch",
    description:
      "Transcutaneous auricular vagus nerve stimulation, often shortened to taVNS, is the ear-based version of tVNS and is commonly discussed in relation to auricular vagal pathways.",
  },
];

const termCards = [
  {
    title: "tVNS",
    label: "Transcutaneous VNS",
    description:
      "A broad term for vagus nerve stimulation approaches delivered through the skin using external contact rather than implanted hardware.",
  },
  {
    title: "taVNS",
    label: "Auricular tVNS",
    description:
      "The ear-based form of tVNS. It is usually discussed in relation to specific outer-ear regions and the auricular branch of the vagus nerve.",
  },
  {
    title: "nVNS",
    label: "Non-invasive VNS",
    description:
      "A wider product and research category that can include different external approaches. tVNS is one way people describe non-invasive stimulation methods.",
  },
  {
    title: "Cervical nVNS",
    label: "Neck-based approach",
    description:
      "A non-invasive approach applied near the neck area. It should not be collapsed into ear-based taVNS or treated as identical to every tVNS method.",
  },
];

const whyItMatters = [
  {
    title: "It separates broad categories from specific methods",
    description:
      "VNS, nVNS, tVNS, taVNS, and vagus nerve stimulator are related terms, but they do not describe the same delivery route or protocol. Separating them keeps evidence interpretation precise.",
  },
  {
    title: "It keeps evidence in the right lane",
    description:
      "A study using one stimulation site or parameter set does not automatically support every device, use case, or claim. tVNS should be read through method details.",
  },
  {
    title: "It gives users better evaluation criteria",
    description:
      "A user should know to ask about placement, comfort, session length, guidance, stimulation settings, safety boundaries, side effects, and intended use — not just whether something says VNS.",
  },
  {
    title: "It supports responsible product education",
    description:
      "For Neuvago, tVNS is useful method context while the product itself remains focused on wellness support, guided sessions, and daily routine design.",
  },
];

const evaluationCriteria = [
  { title: "Stimulation site", description: "Auricular and cervical stimulation are different access routes. The exact ear or neck location should be reported rather than hidden behind the generic label tVNS." },
  { title: "Electrode and contact design", description: "Electrode geometry, contact area, montage, polarity, and how contact is maintained can change current delivery and the user experience." },
  { title: "Frequency, pulse width, and waveform", description: "Technical parameters shape what was actually delivered. Two studies called tVNS can use materially different electrical protocols." },
  { title: "Intensity and threshold method", description: "Look for how intensity was selected: fixed, sensory-threshold based, individually titrated, or adjusted during the session. Sensation alone is not proof of target engagement." },
  { title: "Dose and timing", description: "Session length, duty cycle, sessions per day or week, treatment duration, and timing relative to tasks or outcomes all matter when comparing studies." },
  { title: "Comparator, population, and outcome", description: "Sham site, blinding, participant population, follow-up window, and whether an outcome is physiological, imaging-based, subjective, or clinical determine what a result can support." },
];


const evidenceReading = [
  { title: "There is no single standard tVNS dose", description: "Consensus reporting guidance exists because site, device, waveform, intensity, duty cycle, session duration, and study design vary substantially across the literature." },
  { title: "Target engagement is not one universal biomarker", description: "Studies use different physiological, neuroimaging, behavioral, and clinical outcomes. A change in one measure should not be treated as a complete readout of vagal activity." },
  { title: "Sham design matters", description: "A control condition can differ by site, intensity, sensation, and blinding success. That affects how confidently active and control groups can be compared." },
  { title: "Safety reporting has been inconsistent", description: "Systematic safety reviews have found that adverse-event reporting is not uniform across taVNS studies. Tolerability claims should therefore stay tied to the actual evidence and protocol." },
];

const methodBoundaries = [
  {
    title: "tVNS is not the same as implanted VNS",
    description:
      "Implanted clinical VNS and transcutaneous VNS are related categories, but they differ in hardware, exposure, regulation, indications, and evidence. They should not be treated as interchangeable.",
  },
  {
    title: "taVNS is not every form of tVNS",
    description:
      "Auricular VNS is a specific ear-based branch. It is useful to understand separately because placement, comfort, and research language differ from neck-based approaches.",
  },
  {
    title: "Sensation is not proof of mechanism",
    description:
      "Tingling, pressure, warmth, or comfort can be part of the user experience, but sensation alone does not prove a specific vagal mechanism or clinical outcome.",
  },
  {
    title: "Study findings are protocol-specific",
    description:
      "Research should be interpreted by device, site, parameter set, population, control condition, and outcome. That is especially important in broad wellness communication.",
  },
];

const neuvagoFit = [
  {
    title: "A simpler explanation for a technical category",
    description:
      "Neuvago can make tVNS understandable without turning the product page into a dense research manual, borrowing clinical indications, or making claims beyond the intended wellness use.",
  },
  {
    title: "Guidance matters as much as hardware",
    description:
      "For everyday use, a device-and-app system should help with placement, comfort, session rhythm, and consistency rather than leaving people to interpret technical terms alone.",
  },
  {
    title: "From method to everyday use",
    description:
      "When moving from tVNS methods to Neuvago, the practical questions are how sessions work, how the app guides the routine, and how the product stays within clear wellness boundaries.",
  },
];

const relatedLearning = [
  {
    title: "How to choose a VNS device",
    description:
      "Check how a product explains stimulation site, electrode contact, parameters, target evidence, safety, total ownership, and current commercial terms.",
    href: "/learn/how-to-choose-a-vagus-nerve-stimulation-device",
    linkLabel: "Open the buyer guide",
  },
  {
    title: "Ear-based vs. neck-based VNS",
    description:
      "See why auricular and cervical stimulation need different anatomy, hardware, target-engagement, and protocol questions.",
    href: "/learn/ear-vs-neck-vagus-nerve-stimulation",
    linkLabel: "Compare ear and neck VNS",
  },
  {
    title: "Auricular vagus nerve stimulation",
    description:
      "Go deeper into the ear-based branch of tVNS, including taVNS, auricular placement language, comfort, and responsible claims.",
    href: "/learn/auricular-vagus-nerve-stimulation",
    linkLabel: "Read auricular VNS guide",
  },
  {
    title: "Non-invasive vagus nerve stimulation",
    description:
      "Step back to the broader non-invasive VNS category, including nVNS, tVNS, taVNS, device differences, and wellness boundaries.",
    href: "/learn/non-invasive-vagus-nerve-stimulation",
    linkLabel: "Read non-invasive VNS guide",
  },
  {
    title: "Vagus nerve stimulation overview",
    description:
      "Understand the full VNS category, including implanted systems, external approaches, research context, and clear wellness boundaries.",
    href: "/learn/vagus-nerve-stimulation",
    linkLabel: "Read VNS overview",
  },
  {
    title: "Vagus nerve basics",
    description:
      "Start with the anatomy and regulation foundation before moving into device categories and stimulation methods.",
    href: "/learn/vagus-nerve",
    linkLabel: "Understand the vagus nerve",
  },
];

const researchPathways = [
  {
    title: "Transcutaneous VNS research",
    description:
      "Move from this plain-language guide into the research topic on tVNS, taVNS, stimulation sites, protocol variables, and reporting standards.",
    href: "/research/topics/transcutaneous-vagus-nerve-stimulation",
    linkLabel: "View tVNS research",
  },
  {
    title: "Safety and tolerability",
    description:
      "Understand how adverse events, comfort, contraindication awareness, and device differences shape responsible interpretation of non-invasive VNS.",
    href: "/research/topics/safety-and-tolerability",
    linkLabel: "View safety topic",
  },
  {
    title: "Autonomic regulation",
    description:
      "Connect tVNS language to the wider physiology of sympathetic and parasympathetic state-shifting, HRV, stress, and recovery.",
    href: "/research/topics/autonomic-regulation",
    linkLabel: "View regulation topic",
  },
  {
    title: "Auricular fMRI study",
    description:
      "Read Neuvago’s summary of a foundational paper on non-invasive stimulation of external-ear regions and central vagal projections.",
    href: "/research/studies/frangos-2015-auricular-vagus-nerve-stimulation-fmri",
    linkLabel: "Read study summary",
  },
];

const nextPaths = [
  {
    title: "See how Neuvago works",
    description:
      "Move from tVNS education into the practical device-and-app explanation: placement, guided sessions, comfort, and daily routine design.",
    href: "/how-it-works",
    linkLabel: "See how it works",
  },
  {
    title: "Explore the product",
    description:
      "Understand Neuvago as a non-invasive vagus nerve stimulator and app system designed for calm, repeatable wellness support.",
    href: "/product",
    linkLabel: "Explore Neuvago",
  },
  {
    title: "Review intended use",
    description:
      "See how Neuvago explains wellness boundaries and what the device is not intended to diagnose, treat, cure, or replace.",
    href: "/legal/intended-use",
    linkLabel: "Review intended use",
  },
];

const externalReferences = [
  {
    title:
      "Critical Review of Transcutaneous Vagus Nerve Stimulation: Challenges for Translation to Clinical Practice",
    source: "Yap et al., Frontiers in Neuroscience, 2020",
    href: "https://pubmed.ncbi.nlm.nih.gov/32410932/",
  },
  {
    title:
      "International consensus based review and recommendations for minimum reporting standards in tVNS research",
    source: "Farmer et al., Frontiers in Human Neuroscience, 2021",
    href: "https://pubmed.ncbi.nlm.nih.gov/33854421/",
  },
  {
    title:
      "Non-invasive access to the vagus nerve central projections via electrical stimulation of the external ear",
    source: "Frangos et al., Brain Stimulation, 2015",
    href: "https://pubmed.ncbi.nlm.nih.gov/25573069/",
  },
  {
    title:
      "Safety of transcutaneous auricular vagus nerve stimulation: a systematic review and meta-analysis",
    source: "Kim et al., Scientific Reports, 2022",
    href: "https://pubmed.ncbi.nlm.nih.gov/36543841/",
  },
  {
    title:
      "Clinical application of transcutaneous auricular vagus nerve stimulation: a scoping review",
    source: "2024 scoping review",
    href: "https://pubmed.ncbi.nlm.nih.gov/38362860/",
  },
];

function TextCard({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <article className="rounded-[1.5rem] border border-black/5 bg-white/60 p-6 shadow-[0_12px_40px_rgba(31,31,28,0.04)]">
      <h3 className="text-xl font-medium leading-tight text-[#1f1f1c]">
        {title}
      </h3>
      <p className="mt-4 text-sm leading-7 text-[#5f5a52] md:text-base">
        {description}
      </p>
    </article>
  );
}

function TermCard({
  title,
  label,
  description,
}: {
  title: string;
  label: string;
  description: string;
}) {
  return (
    <article className="rounded-[1.5rem] border border-black/5 bg-white/60 p-6 shadow-[0_12px_40px_rgba(31,31,28,0.04)]">
      <p className="text-xs uppercase tracking-[0.16em] text-[#8a847b]">
        {label}
      </p>
      <h3 className="mt-3 text-xl font-medium leading-tight text-[#1f1f1c]">
        {title}
      </h3>
      <p className="mt-4 text-sm leading-7 text-[#5f5a52] md:text-base">
        {description}
      </p>
    </article>
  );
}

function LinkCard({
  title,
  description,
  href,
  linkLabel,
}: {
  title: string;
  description: string;
  href: string;
  linkLabel: string;
}) {
  return (
    <article className="rounded-[2rem] border border-black/5 bg-white/60 p-8 shadow-[0_12px_40px_rgba(31,31,28,0.04)]">
      <h3 className="text-2xl font-medium leading-tight text-[#1f1f1c]">
        {title}
      </h3>
      <p className="mt-4 text-sm leading-7 text-[#5f5a52] md:text-base">
        {description}
      </p>
      <Link
        href={href}
        className="mt-8 inline-flex text-sm font-medium text-[#1f1f1c] underline-offset-4 transition hover:underline"
      >
        {linkLabel}
      </Link>
    </article>
  );
}

function ExternalReferenceCard({
  title,
  source,
  href,
}: {
  title: string;
  source: string;
  href: string;
}) {
  return (
    <article className="rounded-[1.5rem] border border-black/5 bg-white/60 p-6 shadow-[0_12px_40px_rgba(31,31,28,0.04)]">
      <p className="text-xs uppercase tracking-[0.16em] text-[#8a847b]">
        {source}
      </p>
      <h3 className="mt-3 text-xl font-medium leading-tight text-[#1f1f1c]">
        {title}
      </h3>
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className="mt-6 inline-flex text-sm font-medium text-[#1f1f1c] underline-offset-4 transition hover:underline"
      >
        Open source
      </a>
    </article>
  );
}

export default function TranscutaneousVagusNerveStimulationPage() {
  const structuredData = buildAuthorityPageStructuredData({
    title,
    description,
    path,
    articleSection: "Learn",
    datePublished: authorityEditorialDates.vnsClusterPublished,
    dateModified: authorityEditorialDates.vnsClusterModified,
    keywords: [
      "transcutaneous vagus nerve stimulation",
      "tVNS",
      "transcutaneous VNS",
      "transcutaneous auricular vagus nerve stimulation",
      "taVNS",
      "non-invasive vagus nerve stimulation",
      "auricular vagus nerve stimulation",
      "vagus nerve stimulator",
      "Neuvago",
    ],
    breadcrumbs: [
      { name: "Home", path: "/" },
      { name: "Learn", path: "/learn" },
      { name: "Transcutaneous Vagus Nerve Stimulation", path },
    ],
  });

  return (
    <main className="bg-[#f7f4ef] text-[#1f1f1c]">
      <JsonLd
        data={structuredData}
        idPrefix="learn-transcutaneous-vagus-nerve-stimulation"
      />

      <section className="border-b border-black/5">
        <div className="mx-auto grid lg:min-h-[80vh] max-w-7xl items-center gap-16 px-6 py-20 md:px-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-28">
          <div className="max-w-3xl">
            <p className="mb-5 text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Learn / Transcutaneous VNS
            </p>

            <h1 className="text-4xl font-medium leading-[1.05] tracking-[-0.03em] md:text-6xl lg:text-7xl">
              Transcutaneous vagus nerve stimulation (tVNS): methods, parameters, and evidence
            </h1>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              Transcutaneous vagus nerve stimulation, often called tVNS, means
              stimulation delivered through the skin rather than through an
              implanted device. It is one of the most important terms to
              understand when evaluating non-invasive vagus nerve stimulation.
            </p>

            <p className="mt-5 max-w-2xl text-base leading-8 text-[#5f5a52]">
              This guide explains what tVNS means, how it relates to taVNS and
              auricular VNS, why method details matter, and how Neuvago keeps
              the category clear without turning research language into broad
              medical claims.
            </p>

            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                href="/research/topics/transcutaneous-vagus-nerve-stimulation"
                className="rounded-full bg-[#1f1f1c] px-6 py-3 text-sm font-medium text-white transition hover:opacity-90"
              >
                View tVNS research
              </Link>

              <Link
                href="/learn/auricular-vagus-nerve-stimulation"
                className="rounded-full border border-[#d8d1c7] bg-transparent px-6 py-3 text-sm font-medium text-[#1f1f1c] transition hover:bg-white/70"
              >
                Auricular VNS guide
              </Link>
            </div>
          </div>

          <div className="hidden rounded-[2rem] border border-black/5 bg-white/50 p-4 shadow-[0_20px_80px_rgba(31,31,28,0.08)] backdrop-blur lg:block">
            <div className="rounded-[1.75rem] bg-[#efe8de] p-6 md:p-8">
              <div className="aspect-[4/5] rounded-[1.5rem] border border-black/5 bg-gradient-to-b from-[#f9f6f1] to-[#e7dfd4] p-6">
                <div className="flex h-full flex-col justify-between rounded-[1.25rem] border border-white/60 bg-white/40 p-6">
                  <div>
                    <p className="text-xs uppercase tracking-[0.16em] text-[#8a847b]">
                      Method layer
                    </p>
                    <h2 className="mt-3 text-2xl font-medium text-[#1f1f1c]">
                      tVNS connects the broad VNS category with the practical
                      details of external stimulation
                    </h2>
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-2xl bg-white/70 p-4">
                      <p className="text-sm font-medium text-[#1f1f1c]">
                        tVNS
                      </p>
                      <p className="mt-1 text-sm leading-6 text-[#5f5a52]">
                        Transcutaneous vagus nerve stimulation
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-2xl bg-white/70 p-4">
                        <p className="text-sm font-medium text-[#1f1f1c]">
                          taVNS
                        </p>
                        <p className="mt-1 text-sm leading-6 text-[#5f5a52]">
                          Ear-based branch
                        </p>
                      </div>

                      <div className="rounded-2xl bg-white/70 p-4">
                        <p className="text-sm font-medium text-[#1f1f1c]">
                          nVNS
                        </p>
                        <p className="mt-1 text-sm leading-6 text-[#5f5a52]">
                          Non-invasive family
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <AuthorityVisualSection
        eyebrow="tVNS education visual"
        title="A calmer way to understand stimulation through the skin"
        description="The transcutaneous VNS guide can show the method conceptually while avoiding clinical equipment, anatomy diagrams, and over-specific product claims."
        image={{ src: "/images/neuvago/transcutaneous-vns-education-desktop.webp", alt: "Neuvago device beside abstract transcutaneous VNS method cards." }}
      />

      <PlainEnglishSummary
        title="Transcutaneous VNS means stimulation through the skin"
        description="tVNS is a method term. It can include ear-based taVNS and other non-invasive approaches, but the method details still shape what a study or device experience can responsibly mean."
        points={[
          { title: "Method first", description: "Start by asking where stimulation is applied, what parameters are used, and what outcome is being measured." },
          { title: "Comfort and control", description: "A consumer wellness experience should be guided, comfortable, and easy to stop or adjust within intended-use boundaries." },
          { title: "Evidence does not transfer automatically", description: "A protocol in a research study should not be treated as proof for every device or routine." },
        ]}
        primaryHref="/research/topics/transcutaneous-vagus-nerve-stimulation"
        primaryLabel="View tVNS research"
        secondaryHref="/research/topics/safety-and-tolerability"
        secondaryLabel="Review safety"
      />

      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 py-24 md:px-10 md:py-28 lg:grid-cols-[1fr_0.95fr] lg:items-start">
          <div>
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Simple answer
            </p>

            <h2 className="mt-4 max-w-3xl text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              tVNS is a non-invasive way of describing stimulation through the skin
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              The term transcutaneous comes from trans, meaning through, and
              cutaneous, meaning skin. In practice, tVNS is used for external
              stimulation approaches that aim to engage vagus nerve-related
              pathways without implanted hardware.
            </p>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52]">
              That makes it a useful category term, but not a product claim by
              itself. The responsible question is always: where is stimulation
              applied, what protocol is used, what evidence is being referenced,
              and what is the intended use?
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {quickAnswers.map((item) => (
              <TextCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f7f4ef]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Terms to know
            </p>

            <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              tVNS, taVNS, nVNS, and auricular VNS are related, but not identical
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              These terms are often used close together. Separating them makes
              the category easier to understand and helps keep Neuvago’s product
              language precise.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {termCards.map((item) => (
              <TermCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 py-24 md:px-10 md:py-28 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div>
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Why it matters
            </p>

            <h2 className="mt-4 max-w-3xl text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              A clear tVNS guide helps users evaluate the category instead of chasing acronyms
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              tVNS is useful language only when it leads to better questions.
              It should help people understand device type, stimulation site,
              session guidance, evidence limits, and wellness boundaries.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {whyItMatters.map((item) => (
              <TextCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f7f4ef]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Evaluation criteria
            </p>

            <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              The important question is not just whether a device says tVNS
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              A better evaluation looks at the details that shape the experience
              and the evidence: where stimulation is applied, what settings are
              used, how sessions are guided, and what claims are made.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {evaluationCriteria.map((item) => (
              <TextCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>
      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">Evidence interpretation</p>
            <h2 className="mt-4 max-w-4xl text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">The tVNS label is only the start of the evidence question</h2>
            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">Minimum reporting standards exist because transcutaneous VNS is methodologically diverse. Site, parameters, comparator, population, and outcome need to be visible before findings can be compared.</p>
          </div>
          <div className="mt-14 grid gap-6 md:grid-cols-2">{evidenceReading.map((item) => (<TextCard key={item.title} {...item} />))}</div>
        </div>
      </section>


      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 py-24 md:px-10 md:py-28 lg:grid-cols-[1fr_0.95fr] lg:items-start">
          <div>
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Boundaries
            </p>

            <h2 className="mt-4 max-w-3xl text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              Clear tVNS guidance should make the limits visible
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              Clear boundaries make the category more trustworthy. They help
              users understand that related research does not automatically
              translate into broad product promises.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {methodBoundaries.map((item) => (
              <TextCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f7f4ef]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Neuvago context
            </p>

            <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              tVNS describes the method; it does not create a medical claim
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              Understanding the category comes before evaluating a non-invasive
              vagus nerve stimulator. The practical questions are placement,
              guidance, comfort, routine, and responsible wellness support.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {neuvagoFit.map((item) => (
              <TextCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 py-24 md:px-10 md:py-28 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div>
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Continue learning
            </p>

            <h2 className="mt-4 max-w-3xl text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              Place tVNS inside the broader VNS and non-invasive VNS picture
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              These pages separate the broader category, the ear-based method,
              product comparison, and the deeper research layer so each question
              stays on the right page.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {relatedLearning.map((item) => (
              <LinkCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f7f4ef]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Research and trust
            </p>

            <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              Go deeper into the research layer when you want protocol detail
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              The Learn page gives a practical overview. The Research pages go
              deeper into method details, safety, autonomic regulation, and key
              study context.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {researchPathways.map((item) => (
              <LinkCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-black/5 bg-[#f2eee8]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-28">
          <div className="max-w-3xl">
            <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
              Selected references
            </p>

            <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
              Research context for understanding tVNS and taVNS
            </h2>

            <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
              These sources help frame transcutaneous VNS as a research method
              with technical variables, reporting standards, and safety context.
            </p>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {externalReferences.map((item) => (
              <ExternalReferenceCard key={item.title} {...item} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#f7f4ef]">
        <div className="mx-auto max-w-7xl px-6 py-24 md:px-10 md:py-32">
          <div className="rounded-[2.5rem] border border-black/5 bg-gradient-to-br from-[#efe7dc] to-[#e5dbcf] px-8 py-14 shadow-[0_20px_80px_rgba(31,31,28,0.06)] md:px-12 md:py-16">
            <div className="max-w-3xl">
              <p className="text-sm uppercase tracking-[0.18em] text-[#7a756c]">
                Next step
              </p>

              <h2 className="mt-4 text-3xl font-medium leading-tight tracking-[-0.03em] md:text-5xl">
                From tVNS education to practical guided use
              </h2>

              <p className="mt-6 max-w-2xl text-base leading-8 text-[#5f5a52] md:text-lg">
                Once the terminology is clear, the practical question is how a
                guided non-invasive system fits into everyday life with comfort,
                consistency, and responsible boundaries.
              </p>

              <div className="mt-10 grid gap-6 md:grid-cols-3">
                {nextPaths.map((item) => (
                  <LinkCard key={item.title} {...item} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
