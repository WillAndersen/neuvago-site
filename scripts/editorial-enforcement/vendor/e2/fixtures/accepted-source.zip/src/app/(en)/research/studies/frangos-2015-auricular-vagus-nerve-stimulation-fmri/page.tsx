import type { Metadata } from "next";
import { FeaturedTavnsStudyPage } from "@/components/research-v2";
import { getFeaturedTavnsStudy } from "@/content/research-study-catalog";

const study = getFeaturedTavnsStudy(
  "frangos-2015-auricular-vagus-nerve-stimulation-fmri",
);

export const metadata: Metadata = {
  title: study.metaTitle,
  description: study.metaDescription,
  alternates: { canonical: study.href },
  openGraph: {
    title: study.metaTitle,
    description: study.metaDescription,
    url: study.href,
    siteName: "Neuvago",
    locale: "en_US",
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: study.metaTitle,
    description: study.metaDescription,
  },
};

export default function Frangos2015AuricularVagusNerveStimulationFmriPage() {
  return <FeaturedTavnsStudyPage study={study} />;
}
