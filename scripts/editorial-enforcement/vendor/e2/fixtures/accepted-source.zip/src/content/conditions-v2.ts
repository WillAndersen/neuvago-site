import { commerceContent } from "@/content/commerce";

export type ConditionsV2Link = {
  label: string;
  href: string;
};

export type ConditionsV2ConditionItem = {
  id: string;
  title: string;
  description: string;
  href: string;
};

export type ConditionsV2Image = {
  src: string;
  alt: string;
};

export type ConditionsV2Content = {
  hero: {
    visible: boolean;
    eyebrow: string;
    title: string;
    introduction: string;
    supportingCopy: string;
    primaryCta: ConditionsV2Link;
  };
  featured: {
    visible: boolean;
    id: string;
    eyebrow: string;
    title: string;
    description: string;
    items: readonly ConditionsV2ConditionItem[];
  };
  more: {
    visible: boolean;
    eyebrow: string;
    title: string;
    description: string;
    items: readonly ConditionsV2ConditionItem[];
  };
  researchBridge: {
    visible: boolean;
    eyebrow: string;
    title: string;
    introduction: string;
    context: string;
    cta: ConditionsV2Link;
  };
  finalCta: {
    visible: boolean;
    eyebrow: string;
    title: string;
    description: string;
    primaryCta: ConditionsV2Link;
    secondaryCta: ConditionsV2Link;
    image: ConditionsV2Image;
  };
};

const conditionsFinalPrimaryCta = {
  label: commerceContent.ctaLabel,
  href: commerceContent.shopHref,
} satisfies ConditionsV2Link;

export const conditionsV2Content = {
  hero: {
    visible: true,
    eyebrow: "CONDITIONS",
    title: "Explore conditions through a nervous system lens.",
    introduction:
      "Browse clear, science-informed articles on stress, sleep, anxiety, migraine and headache, gut–brain function and digestion, burnout, depression and mood, chronic pain and related concerns.",
    supportingCopy:
      "Each article begins with the condition or concern itself, then explores the relevant nervous system, vagus nerve and research context in clear, accessible language.",
    primaryCta: {
      label: "Browse conditions",
      href: "#featured-conditions",
    },
  },
  featured: {
    visible: true,
    id: "featured-conditions",
    eyebrow: "FEATURED CONDITIONS",
    title: "Start with a condition or concern.",
    description:
      "Choose the topic that feels most relevant to you.",
    items: [
      {
        id: "stress",
        title: "Stress",
        description:
          "Explore how prolonged stress can affect autonomic regulation, sleep, recovery and the body's ability to settle after demanding moments.",
        href: "/conditions/stress",
      },
      {
        id: "sleep",
        title: "Sleep",
        description:
          "Understand how nervous system activation and stress can affect winding down, sleep quality and the ability to return to sleep.",
        href: "/conditions/sleep",
      },
      {
        id: "anxiety",
        title: "Anxiety",
        description:
          "Explore how anxiety can overlap with autonomic arousal, vigilance, physical sensations, breathing and sleep.",
        href: "/conditions/anxiety",
      },
      {
        id: "migraine-headache",
        title: "Migraine & Headache",
        description:
          "Learn about the complex neurological pathways involved in migraine and headache, and why vagus nerve stimulation is being studied in this field.",
        href: "/conditions/migraine-and-headache",
      },
      {
        id: "gut-brain-digestion",
        title: "Gut–Brain & Digestion",
        description:
          "Explore how the gut and brain communicate through neural, immune and hormonal pathways, including the vagus nerve, and how these pathways are being studied in relation to digestive symptoms.",
        href: "/conditions/gut-brain-and-digestion",
      },
    ],
  },
  more: {
    visible: true,
    eyebrow: "MORE CONDITIONS",
    title: "Explore more conditions and concerns.",
    description:
      "Continue with articles on burnout, depression and mood, chronic pain, and how these topics may intersect with sleep, stress, recovery and nervous system regulation.",
    items: [
      {
        id: "burnout",
        title: "Burnout",
        description:
          "Understand how prolonged demand, exhaustion, disrupted sleep and reduced recovery can overlap over time.",
        href: "/conditions/burnout",
      },
      {
        id: "depression-mood",
        title: "Depression & Mood",
        description:
          "Explore how mood, stress systems, sleep and brain–body regulation are studied together.",
        href: "/conditions/depression-and-mood",
      },
      {
        id: "chronic-pain",
        title: "Chronic Pain",
        description:
          "Learn how pain, stress, sleep and autonomic regulation can interact and reinforce one another over time.",
        href: "/conditions/chronic-pain",
      },
    ],
  },
  researchBridge: {
    visible: true,
    eyebrow: "RESEARCH",
    title: "Explore what the science says.",
    introduction:
      "A growing body of research is examining vagus nerve stimulation and transcutaneous auricular vagus nerve stimulation (taVNS) across areas including sleep, stress, anxiety and mood, migraine and headache, gut–brain function, chronic pain, autonomic regulation, heart rate variability (HRV), safety and tolerability.",
    context:
      "Findings are encouraging across several areas, while results vary between devices, stimulation protocols and study populations.",
    cta: {
      label: "Explore Research",
      href: "/research",
    },
  },
  finalCta: {
    visible: true,
    eyebrow: "NEUVAGO",
    title: "Explore a practical approach to vagus nerve stimulation.",
    description:
      "Neuvago combines four 20-minute stimulation modes with 30 adjustable intensity levels in a simple handheld device designed to support better sleep, calmer responses to everyday stress, focused time and recovery.",
    primaryCta: conditionsFinalPrimaryCta,
    secondaryCta: {
      label: "Explore the Product",
      href: "/product",
    } satisfies ConditionsV2Link,
    image: {
      src: "/images/neuvago/launch/product-hero-desktop.webp",
      alt: "Neuvago vagus nerve stimulation device.",
    },
  },
} as const satisfies ConditionsV2Content;
