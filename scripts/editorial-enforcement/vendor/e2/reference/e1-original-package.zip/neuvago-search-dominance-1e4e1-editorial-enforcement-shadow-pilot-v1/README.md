# NEUVAGO 1E.4E.1 — Editorial Enforcement Contract & Shadow Pilot

Denne pakken er en **skrivebeskyttet prototype i observasjonsmodus**. Ingen CI-regler, hooks eller publiseringssperrer installeres. Den tildeler ingen faglig claim-godkjenning.

## Kjøring

Pakk ut utenfor prosjektet og kjør `run-1e4e1.sh "$HOME/neuvago-site"` med `/bin/bash`. Driveren bruker Python 3.10+, Git, Node 18+ og prosjektets allerede installerte TypeScript-modul. Ingen avhengigheter installeres.

Den faktiske prosjektkjøringen krever ren `main` på **4c4e65a87163000ee493f264849824f17fdcf8ca**, samsvar med origin/main og remote main, samt alle 252 avtalte filhashene. Symbolske aliaser til repo-roten aksepteres; undermapper eller symbolske lenker i de kontrollerte kildefilene avvises. Vanlig `.git`-mappe kreves; linked worktrees er ikke med i denne piloten.

`git ls-remote` er den eneste nettverkslesingen. Pakken bruker ikke fetch. Den avviser omdirigert Git-miljø og fjerner NODE_OPTIONS/NODE_PATH fra underprosessmiljøet for å unngå Node-preloads. Eksisterende TypeScript lastes via en eksplisitt filbane og får egen SHA-256. Prosjektets sidekode og importer kjøres ikke.

## Kontrollerte representasjoner

Arbeidstre, Git-index og den navngitte baseline-committen leses separat. På denne rene baselinen skal innholdet være identisk, men hver fase får eget resultat og eget snapshot-fingeravtrykk. Testene prøver også forskjellige staged/unstaged bytes og nye commits i **isolerte testrepoer**, ikke i brukerprosjektet.

En avgrenset TypeScript-AST-leser tolker bare statiske uttrykk, literaldata og de konkrete `.map`-mønstrene i kildekortene. Den importerer ikke sidemoduler, kjører ikke generert JavaScript og starter ikke Next.js. Ukjent syntaks blir synlig som NOT_EVALUATED eller OPERATIONAL_ERROR; det blir ikke omtalt som «ingen kilder».

Dette er ikke nettleserrendering. Eksplisitt skjult innhold kan oppdages i de støttede mønstrene, men CSS, responsive regler, stilark, runtime-tilstand og nettleserlayout kontrolleres ikke. JSON-LD-komponenten behandles som ugjennomsiktig. Det finnes ingen automatisk vitenskapelig vurdering av fritekst.

## Omfang

- Elleve avtalt leverte sidemoduler, 23 kildekort, elleve eksplisitte kildeavsnitt.
- Per-kort-tolkningsgrenser og åtte separate tolknings-/veiledningsnoter fra D4–D6.
- To ordlistedata-eksempler (`vagal-tone`, EN/NO), ikke 74 ferdig vurderte ordlisteartikler.
- Tre eksisterende registre, to karanteneposter, 27 historiske locks og tidligere kildekorreksjoner.
- Alle 252 låste filer bevares. Filer uten semantisk regeldekning oppgis i dekningsrapportene. Andre Git-baner er kun metadata, ikke innholdskopier.

**G-ID** sammenholder identitetene innenfor samme avtalte kort. Merket DOI-tekst eller DOI-lenke er gyldige alternativer. Offentlige kilder trenger ikke forskningsidentifikatorer.

**G-REVIEW** oppdager nye godkjenningskoblinger, direkthets-/sikkerhetspromoteringer og brede godkjenningsflagg. Nye review-beslutninger kan ikke godkjennes eller importeres av E1.

**G-SCOPE** kontrollerer per-bruk-avgrensninger og historikk. Fjernet eller eksplisitt skjult note gir WOULD_BLOCK. Ny noteformulering gir REVIEW_REQUIRED; den kan ikke usynlig arve gammel review.

**G-ROUTES** viser erklært dekning og uavklarte importer/ruter. Ingen nye policy-/rutekoblinger utledes fra ordlikhet. Nye eller endrede forklaringer blir review selv om ingen av de 117 policyene matcher leksikalsk.

**G-LIFECYCLE** binder observasjonene til inputfase, filhash, blob, snapshot, regelkode, kontrakt og TypeScript-modul. Index leses fra Git-objekter, ikke fra potensielt andre arbeidsfiler. Delvis staging og forskjeller mellom index/arbeidstre demonstreres uten å endre brukerens repo.

## Rapportering er ikke publisering

`PASS_TECHNICAL_SCOPE`, `WOULD_BLOCK`, `REVIEW_REQUIRED`, `NOT_EVALUATED` og `OPERATIONAL_ERROR` er separate regelutfall. `COMPLETE` betyr at rapporteringen lyktes; en komplett rapport kan inneholde blokkeringskandidater og review-punkter. Uleselig eller ugyldig input får aldri et falskt PASS.

Alle 110 videreførte D7-funn og de sju review-sporene følger med uten ny klassifisering. Tolv dokumenterte kildekandidater er ikke automatisk kildefeil, og de 23 kildebrukene er ikke godkjente claim-koblinger. De elleve manglende eksplisitte policy-/rutekoblingene forblir review.

`approved_links: 0`, `release_ready: false`, `enforcement_gates_installed: false`, `claim_support_review_complete: false` beholdes. Teknisk identitetsmatch mot akseptert kontrakt er ikke en ny ekstern kildeverifikasjon.

## Feilkontroller og historisk HTML

Pakken gjennomfører 45 navngitte positiv-/feilkontroller i minnet. Forventede WOULD_BLOCK/OPERATIONAL_ERROR er **tilsiktede testresultater**, ikke feil funnet i ditt repo. Ytterligere tester dekker real-Git-faser i isolerte lokale repoer og ikke-muterende gjenkjøring.

Elleve historiske HTML-filer fra de tidligere, gjennomgåtte sluttpakkene følger som kontrollfiksturer. Deres originalhash, tidsstempel og kildearkiv er dokumentert i `reference/html-fixture-origins.json`. De parses separat fra kildekoden. En slik kontroll er ikke en ny produksjonshenting eller attestasjon av dagens deploy.

## Utdata

En unik rapportmappe under `Downloads`, utenfor repoet, inneholder:

- `RESULT.json` og `SUMMARY.md`.
- `phases/worktree.json`, `phases/index.json`, `phases/commit.json`.
- Separate `coverage/`-filer, inklusive NOT_EVALUATED scope.
- `fault-demonstrations.json` med forventninger og faktiske regelutfall.
- `historical-html-controls.json` med tydelig historisk status.
- `carry-forward/` og `review-lanes.json` med uendret faglig restarbeid.
- `audit/` før, etter og ved avslutning; SHA-256 av Git-kontrollfiler, ikke hemmelig innhold.
- Testlogg og rapportmanifest.

Retur-ZIP og relativ SHA-256-fil opprettes ved suksess og ved håndterte feil. Ingen manuell reset, stash, gjenoppretting eller opprydding i prosjektet utføres.

Forventet status: `PASS_1E4E1_EDITORIAL_ENFORCEMENT_SHADOW_PILOT_CAPTURED`.

Neste gate: `RETURN_1E4E1_SHADOW_RESULTS_FOR_RULE_REVIEW`.

## Kildegrunnlag

Designen fra forrige leveranse er vedlagt uendret i `reference/design-v1.md` og `.json`. D7-overleveringen og de fem regelfamiliene beholdes. Dette er første avgrensede implementasjon, ikke full installasjon av E1–E3 eller faglig lukking av 1E.4D. Kliniske kilder er ikke undersøkt på nytt i denne pakken.
